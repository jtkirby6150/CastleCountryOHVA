<div id="footer" style="margin-top: 25px;">
    <div class="row">
        <div class="col-md-6">
            <p style="font-size: 20px;"><small>All rights reserved &copy; Castle Country OHV Association
                    <script type="text/javascript">
                        var cur = 1999;
                        var year = new Date();
                        if (cur == year.getFullYear()) year = year.getFullYear();
                        else year = cur + ' - ' + year.getFullYear();
                        document.write(year);
                    </script>
                </small></p>
        </div>
        <div class="col-md-6" style="text-align: right">
            <p style="font-size: 20px;">Visit us on&nbsp;&nbsp;<a href="https://www.facebook.com/groups/ccohva.org" target="_blank"><i class="fa fa-facebook-square" style="font-size: 24px;"></i>&nbsp;</a></p>
        </div>
    </div>
</div>
</div>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox.min.js"></script>
<script src="assets/js/script.min.js"></script>
</body>

</html>