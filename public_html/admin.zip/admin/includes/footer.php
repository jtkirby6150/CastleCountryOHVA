
<div id="footer" style="margin-top: 25px;">
    <div class="row">
        <div class="col-md-6">
            <p style="font-size: 20px;"><small>All rights reserved &copy; Castle Country OHV Association
                    <script type="text/javascript">
                        var cur = 1999;
                        var year = new Date();
                        if (cur == year.getFullYear()) year = year.getFullYear();
                        else year = cur + ' - ' + year.getFullYear();
                        document.write(year);
                    </script>
                </small></p>
        </div>
        <div class="col-md-6" style="text-align: right">
            <p style="font-size: 20px;">Visit us on&nbsp;&nbsp;<a href="https://www.facebook.com/groups/ccohva.org" target="_blank"><i class="fa fa-facebook-square" style="font-size: 24px;"></i>&nbsp;</a></p>
        </div>
    </div>
</div>
</div>
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox.min.js"></script>
<script src="../assets/js/script.min.js"></script>
<script src="https://cdn.tiny.cloud/1/x2nu2dtvwz38uerxcs6vqc7v0yj8mr843iog9v0dv6f5lwui/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>

<script>
    tinymce.init({
        selector: '#boardMemberDescription',
        plugins: 'lists',
        toolbar: 'numlist bullist',
    });
    tinymce.init({
        selector: '#ptitledescription',
        plugins: 'lists',
        toolbar: 'numlist bullist',
    });
    tinymce.init({
        selector: '#stitledescription',
        plugins: 'lists',
        toolbar: 'numlist bullist',
    });
    tinymce.init({
        selector: '#lmtitledescription',
        plugins: 'lists',
        toolbar: 'numlist bullist',
    });
    tinymce.init({
        selector: '#eventtitledescription',
        plugins: 'lists',
        toolbar: 'numlist bullist',
    });
    tinymce.init({
        selector: '#archivedescription',
        plugins: 'lists',
        toolbar: 'numlist bullist',
    });
    tinymce.init({
        selector: '#newsdescription',
        plugins: 'lists',
        toolbar: 'numlist bullist',
    });
</script>
</body>

</html>